package clubdefutbol;

import java.io.IOException;

public class ClubFutbolApp{

    public static void main(String[] args) throws IOException, ClassNotFoundException {
        
        /*private String nom;
        private String cif;
        private String address;
        private int telefon;
        private String email;
        private String web;*/
    
        ClubFutbol club = new ClubFutbol("Lleida Esportiu","Q2826000H","Lleida, Travessera Dr. Fleming, S/N.", 973249818 ,"gestio@ellleida.com","https://twitter.com/lleida_esportiu");
        club.gestionarClub();
    }
}
