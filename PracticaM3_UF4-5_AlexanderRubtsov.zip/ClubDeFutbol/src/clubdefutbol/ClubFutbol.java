package clubdefutbol;


import Persones.Socis.Soci;
import Persones.Treballadors.Entrenador;
import Persones.Treballadors.Jugadors.Davanter;
import Persones.Treballadors.Jugadors.Jugador;
import Persones.Treballadors.Plantilla;
import Persones.Treballadors.Preparador;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;

public class ClubFutbol implements Serializable{
    
    private String nom;
    private String cif;
    private String address;
    private int telefon;
    private String email;
    private String web;
    HashMap<String, Plantilla> plantilla = new HashMap();
    HashMap<String, Soci> soci = new HashMap();
    
    public ClubFutbol(String nom, String cif, String address, int telefon, String email, String web) {
        this.nom = nom;
        this.cif = cif;
        this.address = address;
        this.telefon = telefon;
        this.email = email;
        this.web = web;
    }
     
    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCif() {
        return cif;
    }

    public void setCif(String cif) {
        this.cif = cif;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public int getTelefon() {
        return telefon;
    }

    public void setTelefon(int telefon) {
        this.telefon = telefon;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getWeb() {
        return web;
    }

    public void setWeb(String web) {
        this.web = web;
    }

    public HashMap<String, Plantilla> getPlantilla() {
        return plantilla;
    }

    public void setPlantilla(HashMap<String, Plantilla> plantilla) {
        this.plantilla = plantilla;
    }

    public HashMap<String, Soci> getSoci() {
        return soci;
    }

    public void setSoci(HashMap<String, Soci> soci) {
        this.soci = soci;
    }
    
    public void gestionarClub() throws IOException, ClassNotFoundException {     
        File file = new File("C:\\Users\\haze9\\Desktop\\DAM\\M3 Programació\\club de futbol\\ClubDeFutbol\\src\\files\\GestioClub.dat");
        if (file.isFile()) {
            llegirDadesFile();
        }

        boolean sortir = false;

        do {
            System.out.println("Gestió de clubs");
            System.out.println("1: Consultar dades del club.");
            System.out.println("2: Gestionar socis.");
            System.out.println("3: Gestionar la plantilla del club.");
            System.out.println("4: Mostrar les dades econòmiques del club.");
            System.out.println("5: Guardar i sortir.");

            int opcio = comprobar();

            switch (opcio) {
                case 1:
                    consultarDadesClub();
                    break;
                case 2:
                    gestionarSocis();
                    break;
                case 3:
                    gestionarPlantilla();
                    break;
                case 4:
                    mostrarDadesEconomiques();
                    break;
                case 5:
                    guardarDadesClub();
                    sortir = true;
                    break;
                default:
                    System.out.println("Introdueix un numero vàl·lid.");
            }
        
        } while (!sortir);
    }

    private void mostrarDadesEconomiques() {
        System.out.println("Ingressos del club actual.");
        double ingres = 0;
        ArrayList<Soci> sociArray = new ArrayList<>();
        Iterator it = sociArray.iterator();
            while (it.hasNext()) {
                Soci s = (Soci) it.next();
                sociArray.add(s);
        }
        
        for (Soci s : sociArray) {
            ingres += s.getQuota();
        }
        
        System.out.println("Quotes de soci: " + ingres+ "€");

        System.out.println("Despeses del club actual.");
        
        double despeses = 0;
        ArrayList<Plantilla> plantillaArray = new ArrayList<>();
        Iterator it2 = plantillaArray.iterator();
            while (it2.hasNext()) {
                Plantilla p = (Plantilla) it2.next();
                plantillaArray.add(p);
        }
        for (Plantilla p : plantillaArray) {
            despeses += p.getSouIncentivat();
        }
        System.out.println("Salari dels treballadors: " + despeses + "€");
    }

    private void consultarDadesClub() {
        
        System.out.println("\nNom: " + this.nom);
        System.out.println("CIF: " + this.cif);
        System.out.println("Adreça: " + this.address);
        System.out.println("Telèfon: " + this.telefon);
        System.out.println("Email: " + this.email);
        System.out.println("Web: " + this.web);
    }

    public void gestionarSocis() {
        Scanner keyboard = new Scanner(System.in);
        boolean exit = false;
        Soci sc = new Soci();
        
        do {
            System.out.println("Gestionar els socis del club actual.");
            System.out.println("1: Visualitzar tots els socis. ");
            System.out.println("2: Donar d'alta un soci. ");
            System.out.println("3: Modificar un soci. ");
            System.out.println("4: Donar de baixa un soci. ");
            System.out.println("5: Enrere. ");

            int opcio = comprobar();       

            switch (opcio) {
                case 1:
                    visualitzarSocis();
                    break;
                case 2:
                    sc = sc.altaSoci();
                    System.out.println(sc);
                    String dni2 = sc.getDni().getDni();
                    soci.put(dni2, sc);
                    System.out.println("Soci donat d'alta correctament!");
                    break;
                case 3:
                    dni2 = null;
                    System.out.println("Escriu el DNI del soci que vols modificar: ");
                    try {
                        dni2 = keyboard.nextLine();
                        sc = soci.get(dni2);
                        sc = sc.modifica(sc);
                    } catch (Exception e) {
                        System.out.println("No s'ha trobat el soci amb el DNI especificat.");
                    }
                    soci.put(dni2, sc);
                    break;
                case 4:
                    try {
                        System.out.print("Escriu el dni del soci que vols donar de baixa: ");
                        dni2 = keyboard.nextLine();
                        if (soci.containsKey(dni2)) {
                            soci.remove(dni2);
                            System.out.println("Soci eliminat correctament!");
                        } else {
                            System.out.println("No s'ha trobat el DNI introduït.");
                        }
                    } catch (Exception e) {
                        System.out.println("No s'ha trobat el soci amb el DNI especificat.");
                    }
                    break;
                case 5:
                    exit = true;
                    break;
                default:
                    System.out.println("Introdueix un numero vàl·lid.");
            }
        } while (!exit);
    }

    private void visualitzarSocis() {
        ArrayList<Soci> arr = new ArrayList<>();
        Scanner keyboard = new Scanner(System.in);
        boolean sortir = false;

        Soci s = new Soci();
        do {
            System.out.println("Vuisualitza els socis actuals del club: ");
            System.out.println("1: Ordenar per cognom. ");
            System.out.println("2: Ordenar per localitat. ");
            System.out.println("3: Ordenar per quota. ");
            System.out.println("4: Enrere. ");

            int opcio = comprobar();
            
            switch (opcio) {
                case 1:
                    arr = s.ordenarCognom(soci);
                    for (Soci soci : arr) {
                        System.out.println(soci);
                    }
                    break;
                case 2:
                    arr = s.ordenarPerLocalitat(soci);
                    for (Soci soci : arr) {
                        System.out.println(soci); 
                    }
                    break;
                case 3:
                    arr = s.ordenarPerQuota(soci);
                    for (Soci soci : arr) {
                        System.out.println(soci);   
                    }
                    break;
                case 4:
                    sortir = true;
                    break;
                default:
                    System.out.println("Introdueix un numero vàl·lid.");
            }
        } while (!sortir);
    }

    public void gestionarPlantilla() {
        boolean sortir = false;

        do {
            System.out.println("Gestiona la plantilla actual.");
            System.out.println("1: Visualitzar la plantilla");
            System.out.println("2: Donar d'alta un treballador");
            System.out.println("3: Modificar un treballador");
            System.out.println("4: Donar de baixa un treballador");
            System.out.println("5: Enrere. ");

            int opcio = comprobar();

            switch (opcio) {
                case 1:
                    visualitzarPlantilla();
                    break;
                case 2:       
                    altaTreballador();
                    break;
                case 3:
                    modificarTreballador();
                    break;
                case 4:
                    baixaTreballador();
                    break; 
                case 5:
                    sortir = true;
                    break;
                default:
                    System.out.println("Introdueix un numero vàl·lid.");
            }
        } while (!sortir);
    }

    private void modificarTreballador() {
        Scanner keyboard = new Scanner(System.in);
        String dni2;
        System.out.print("Escriu el dni del treballador que vols modificar: ");

        try {
            dni2 = keyboard.nextLine();
            plantilla.get(dni2).modifica();
            System.out.println("Treballador modificat correctament!");
        } catch (Exception e) {
            System.out.println("No s'ha trobat el treballador.");
        }
    }

    private void altaTreballador() { 
        boolean exit = false;

        do {
            System.out.println("Quin tipus de treballador vols donar d'alta?");
            System.out.println("1. Davanter");
            System.out.println("2. Migcampista (No implementat)");
            System.out.println("3. Defensa (No implementat)");
            System.out.println("4. Porter (No implementat)");
            System.out.println("5. Entrenador");
            System.out.println("6. Preparador Tècnic");
            System.out.println("7. Enrere");

            int opcio = comprobar();

            switch (opcio) {
                case 1:
                    Davanter d = new Davanter();
                    d = d.altaDavanter();
                    plantilla.put(d.getDni().getDni(), d);
                    System.out.println("Davanter donat d'alta correctament.");           
                    break;
                case 2:
                    
                case 3:
                    
                case 4:
                    
                case 5:
                    Entrenador en = new Entrenador();
                    en = en.altaEntrenador();
                    plantilla.put(en.getDni().getDni(), en);
                    System.out.println("Preparador Físic donat d'alta correctament.");
                case 6:
                    Preparador pt = new Preparador();
                    pt = pt.altaPreparador();
                    plantilla.put(pt.getDni().getDni(), pt);
                    System.out.println("Preparador Físic donat d'alta correctament.");
                    break;
                case 7:
                    exit = true;
                    break;
                default:
                    System.out.println("Introdueix un numero vàl·lid.");
            }
        } while (!exit);
    }

    private void visualitzarPlantilla() {
        ArrayList<Plantilla> arr = new ArrayList();
        boolean sortir = false;

        do {
            System.out.println("Visualitza la plantilla actual.");
            System.out.println("1: Ordenar pel rol del treballador.");
            System.out.println("2: Ordenar pel sou del treballador.");
            System.out.println("3: Enrere.");

            int opcio = comprobar();
            
            switch (opcio) {
                case 1:
                    arr = Plantilla.ordenarPerRol(plantilla);
                    for (Plantilla p : arr) {
                        
                        System.out.println(p);
                    }
                    break;
                case 2:
                    arr = Plantilla.ordenarPerSouIncentivat(plantilla);
                    for (Plantilla p : arr) {
                        System.out.println(p);
                    }                    
                    break;
                case 3:
                    sortir = true;
                    break;
                default:
                    System.out.println("Introdueix un numero vàl·lid.");
            }
        } while (!sortir);
    }
    
    private void baixaTreballador(){
        Scanner keyboard = new Scanner(System.in);
        String dni;
        
        try {
            System.out.print("Escriu el dni del treballador que vols donar de baixa: ");
            dni = keyboard.nextLine();
            if (plantilla.containsKey(dni)) {
                plantilla.remove(dni);
                System.out.println("Treballador donat de baixa correctament!");
            } else {
                System.out.println("No s'ha trobat el DNI del treballador que vols eliminar.");
            }                       
        } catch (Exception e) {
            System.out.println("No s'ha trobat el treballador que ha proporcionat.");
        }
    }
    
    private int comprobar() {
        Scanner kb = new Scanner(System.in);
        int a = 0;
        boolean valid = false;

        while (!valid) {
            try{
                a = Integer.parseInt(kb.nextLine());
                valid = true;
            }catch (NumberFormatException ex) {
                System.out.println("Introdueix un numero.");
            }
        }
        return a;
    }
    
    private void obtenirStaticVar() {
        int maxNumEmpleat = 0;
        int maxDorsal = 0;
        int maxNumSoci = 0;
        int maxLocalitat = 0;
        ArrayList<Plantilla> plantillaArray = new ArrayList<>();
        Iterator it2 = plantillaArray.iterator();
            while (it2.hasNext()) {
                Plantilla p = (Plantilla) it2.next();
                plantillaArray.add(p);
        }

        for (Plantilla p : plantillaArray) {
            if (p.getNumEmpId() > maxNumEmpleat) {
                maxNumEmpleat = p.getNumEmpId();
            }
            if (p instanceof Jugador) {
                Jugador jugador = (Jugador) p;
                if (jugador.getDorsal() > maxDorsal) {
                    maxDorsal = jugador.getDorsal();
                }
            } 
        }

        ArrayList<Soci> sociArray = new ArrayList<>();
        Iterator<Entry<String, Soci>> iterador = soci.entrySet().iterator();
            while (iterador.hasNext()) {
                Entry<String, Soci> entry = iterador.next();
                sociArray.add(entry.getValue());
        }

        for (Soci s : sociArray) {
            if (s.getNumSoci() > maxNumSoci) {
                maxNumSoci = s.getNumSoci();
            }
            if (s.getLocalitat() > maxLocalitat) {
                maxLocalitat = s.getLocalitat();
            }
        }
        Soci.setLocalitatId(maxLocalitat);
        Soci.setNumSociId(maxNumSoci);
        Plantilla.setNumEmpId(maxNumEmpleat);
        Jugador.setDorsalId(maxDorsal);
    }

    private void guardarDadesClub() throws IOException {
        File file = new File("C:\\Users\\haze9\\Desktop\\DAM\\M3 Programació\\club de futbol\\ClubDeFutbol\\src\\files\\GestioClub.dat");
        FileOutputStream fileOutput = new FileOutputStream(file);
        ObjectOutputStream serialitzator = new ObjectOutputStream(fileOutput);
        serialitzator.writeObject(plantilla);
        serialitzator.writeObject(soci);
    }

    private void llegirDadesFile() throws IOException, ClassNotFoundException {
        File file = new File("C:\\Users\\haze9\\Desktop\\DAM\\M3 Programació\\club de futbol\\ClubDeFutbol\\src\\files\\GestioClub.dat");
        if (file.isFile()){
            FileInputStream fileInput = new FileInputStream(file);
            ObjectInputStream dsltz = new ObjectInputStream(fileInput);
            plantilla = (HashMap<String, Plantilla>) dsltz.readObject();
            System.out.println(plantilla);
            soci = (HashMap<String, Soci>) dsltz.readObject();
            System.out.println(soci);
            obtenirStaticVar();
        }
    }
}
