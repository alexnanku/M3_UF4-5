package Persones.Tecnic;

import Comprovacions.Dni;
import Persones.Treballadors.Plantilla;
import java.io.Serializable;
import java.util.Scanner;

public class Tecnic extends Plantilla implements Serializable{
    private int anysExp; 

    public Tecnic(String ss, double souBase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(ss, souBase, souIncentivat, dni, nom, cognom, datanaix);
    }

    public Tecnic() {
    }

    public int getAnysExp() {
        return anysExp;
    }

    public void setAnysExp(int anysExp) {
        this.anysExp = anysExp;
    }
    
     public void altaTecnic() {
        Scanner keyboard = new Scanner(System.in);
        altaPlantilla();
        System.out.print("Escriu els anys d'experiència: ");
        setAnysExp(keyboard.nextInt());
    }
    
    @Override
    public void modifica() {
        Scanner kb = new Scanner(System.in);
        super.modifica();
        System.out.print("Anys d'experiència del tècnic: ");

        int anysExp = kb.nextInt();
        setAnysExp(anysExp);
    }

    @Override
    public String toString() {
        return super.toString() + "Anys d'experiència: " + anysExp;
    }
    
    @Override
    public void calcularSouIncentivat() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
   
    
   
}
