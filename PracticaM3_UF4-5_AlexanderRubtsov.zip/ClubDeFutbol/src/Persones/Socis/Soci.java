package Persones.Socis;

import Comprovacions.Dni;
import Persones.Persona;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;

public class Soci extends Persona implements Comparable<Soci>, Comparator<Soci>, Serializable{
    
    private int numSoci;
    private static int numSociId = 1;
    private int localitat;
    private double quota;
    private static int localitatId = 500;
    
    private transient final Scanner keyboard = new Scanner(System.in);
    
    public Soci(double quota, Dni dni, String nom, String cognom, String datanaix) {
        super(dni, nom, cognom, datanaix);
        this.numSoci = numSociId++;
        this.localitat = localitatId++;
        this.quota = quota;
    }
    
    public Soci(){}

    public int getNumSoci() {
        return numSoci;
    }

    public void setNumSoci(int numSoci) {
        this.numSoci = numSoci;
    }

    public static int getNumSociId() {
        return numSociId;
    }

    public static void setNumSociId(int numSociId) {
        Soci.numSociId = numSociId;
    }

    public int getLocalitat() {
        return localitat;
    }

    public void setLocalitat(int localitat) {
        this.localitat = localitat;
    }

    public double getQuota() {
        return quota;
    }

    public void setQuota(double quota) {
        this.quota = quota;
    }

    public static int getLocalitatId() {
        return localitatId;
    }

    public static void setLocalitatId(int localitatId) {
        Soci.localitatId = localitatId;
    }
    
    public ArrayList<Soci> ordenarCognom(HashMap<String, Soci> socis) {
        ArrayList<Soci> arr = new ArrayList<>();
        Iterator<Entry<String, Soci>> iterador = socis.entrySet().iterator();
        while (iterador.hasNext()) {
            Entry<String, Soci> entry = iterador.next();
            arr.add(entry.getValue());
        }
        Collections.sort(arr);         
        return arr;
    }
    
    public ArrayList<Soci> ordenarPerQuota(HashMap<String, Soci> socis) {
        ArrayList<Soci> arr = new ArrayList<>();
        Iterator<Entry<String, Soci>> iterador = socis.entrySet().iterator();
            
        while (iterador.hasNext()) {
            Entry<String, Soci> entry = iterador.next();
            arr.add(entry.getValue());
        }
        arr.sort(new Comparator<Soci>() {
            @Override
            public int compare(Soci s1, Soci s2) {
                return (int)(s1.getQuota() - s2.getQuota());
            }  
        });
        return arr;
    }
    
    public ArrayList<Soci> ordenarPerLocalitat(HashMap<String, Soci> socis) {
        ArrayList<Soci> arr = new ArrayList<>();
        Iterator<Entry<String, Soci>> iterador = socis.entrySet().iterator();
        while (iterador.hasNext()) {
            Entry<String, Soci> entry = iterador.next();
            arr.add(entry.getValue());
        }
        arr.sort(new Comparator<Soci>() {
            @Override
            public int compare(Soci s1, Soci s2) {
                return (int) s1.getLocalitat() - s2.getLocalitat();
            } 
        });
        
        return arr;
    }
    
    public Soci altaSoci() {
        System.out.print("Escriu la quota del soci: ");
        int quo8 = keyboard.nextInt();
        
        Dni dni = new Dni();
        String dniStr;

        do {
            System.out.print("Escriu el dni del soci: ");
            dniStr = keyboard.next();
        } while (!dni.validarDni(dniStr));
        
        dni.setDni(dniStr);
        setDni(dni);
        
        keyboard.nextLine();

        System.out.print("Escriu el nom del nou soci: ");
        String nom8 = keyboard.nextLine();
        System.out.print("Escriu el cognom del soci: ");
        String cognom8 = keyboard.nextLine();
        
        System.out.print("Escriu la data de naixement del soci: ");
        String datanaix8 = keyboard.nextLine();

        Soci s = new Soci(quo8, dni, nom8, cognom8, datanaix8);
        //System.out.println(s);
        return s;
    }

    public Soci modifica(Soci sci) {
        System.out.println("Modificant al soci: " + sci.getNom() + " " + sci.getCognom());
        super.modifica();

        System.out.print("Escriu la nova quota: ");
        double quota = keyboard.nextInt();
        if (quota != 0) {
            setQuota(quota);
        }
        return sci;
    }

    @Override
    public String toString() {
        return super.toString() + "Numero de soci: " + numSoci + "\nNumero de localitat: " + localitat + "\nQuota: " + quota;
    }

    @Override
    public int compareTo(Soci t) {
        //System.out.println(t);
        return this.getCognom().compareToIgnoreCase(t.getCognom()); 
    }

    @Override
    public int compare(Soci t, Soci t1) {
        return 0;
    }
}