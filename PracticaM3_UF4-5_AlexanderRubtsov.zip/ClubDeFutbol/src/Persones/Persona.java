package Persones;

import Comprovacions.Dni;
import java.io.Serializable;
import java.util.Scanner;

public abstract class Persona implements Serializable{
    
    private Dni dni;
    private String nom;
    private String cognom;
    private String datanaix;
    
    
    public Persona(){}
    
    public Persona(Dni dni, String nom, String cognom, String datanaix) {
        this.dni = dni;
        this.nom = nom;
        this.cognom = cognom;
        this.datanaix = datanaix;
    }

    @Override
    public String toString() {
        return this.getClass().getSimpleName() + "\nDNI: " + dni + "\nNom: " + nom + "\nCognom: " + cognom + "\n Data de naixement: " + datanaix + "\n";
    }

    public Dni getDni() {
        return dni;
    }

    public void setDni(Dni dni) {
        this.dni = dni;
    }

    public String getNom() {
        return nom;
    }

    public void setNom(String nom) {
        this.nom = nom;
    }

    public String getCognom() {
        return cognom;
    }

    public void setCognom(String cognom) {
        this.cognom = cognom;
    }

    public String getDatanaix() {
        return datanaix;
    }

    public void setDatanaix(String datanaix) {
        this.datanaix = datanaix;
    }
    
    public void altaPersona(){
        Scanner keyboard = new Scanner(System.in);
        
        boolean enrere=false;
        
        Dni dni = new Dni();
        String dni2;
        
         do {
            System.out.print("Escriu el DNI de la nova persona afiliada al club: ");
            dni2 = keyboard.next();
        } while (!dni.validarDni(dni2));

        dni.setDni(dni2);
        setDni(dni);
        
        System.out.println("Posar el nom de la nova persona afiliada al club: ");
        String nom = keyboard.next();
        
        System.out.println("Posar el cognom de la nova persona afiliada al club: ");
        String cognom = keyboard.next();
        
        System.out.println("Posar la data naixement de la nova persona afiliada al club: ");
        String data = keyboard.next();
    }
    
    public void modifica() {
        String nom;
        String cognom;
        String data;
        Scanner keyboard = new Scanner(System.in);

        System.out.print("Escriu el nom: ");
        nom = keyboard.nextLine();

        if (!nom.isEmpty()) {
            setNom(nom);
        }

        System.out.print("Escriu el cognom: ");
        cognom = keyboard.nextLine();

        if (!cognom.isEmpty()) {
            setCognom(cognom);
        }
 
        System.out.println("Escriu la data de naixement: ");
        data = keyboard.next();
    }
}

