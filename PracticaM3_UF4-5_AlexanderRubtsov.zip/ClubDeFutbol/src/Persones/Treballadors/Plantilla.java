package Persones.Treballadors;

import Comprovacions.Dni;
import Persones.Persona;
import java.io.Serializable;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map.Entry;
import java.util.Scanner;

public abstract class Plantilla extends Persona  implements Comparable<Plantilla>, Comparator<Plantilla>, Serializable{
    
    private int numEmp;
    private static int numEmpId = 1;
    private String ss; //seguretat social
    private double souBase;
    private double souIncentivat;

    public Plantilla(String ss, double souBase, double souIncentivat,Dni dni, String nom, String cognom, String datanaix) {
        super(dni, nom, cognom, datanaix);
        this.numEmp = numEmpId++;
        this.ss = ss;
        this.souBase = souBase;
        this.souIncentivat = souIncentivat;
    }
    
    public Plantilla(){}
    
    public int getNumEmp() {
        return numEmp;
    }

    public void setNumEmp(int numEmp) {
        this.numEmp = numEmp;
    }

    public static int getNumEmpId() {
        return numEmpId;
    }

    public static void setNumEmpId(int numEmpId) {
        Plantilla.numEmpId = numEmpId;
    }

    public String getSs() {
        return ss;
    }

    public void setSs(String ss) {
        this.ss = ss;
    }

    public double getSouBase() {
        return souBase;
    }

    public void setSouBase(double souBase) {
        this.souBase = souBase;
    }

    public double getSouIncentivat() {
        return souIncentivat;
    }

    public void setSouIncentivat(double souIncentivat) {
        this.souIncentivat = souIncentivat;
    }
    
    public static ArrayList<Plantilla> ordenarPerSouIncentivat(HashMap<String, Plantilla> p) {
        ArrayList<Plantilla> al = new ArrayList<>();
        Iterator<Entry<String, Plantilla>> iterador = p.entrySet().iterator();
            
        while (iterador.hasNext()) {
            Entry<String, Plantilla> entry = iterador.next();
            al.add(entry.getValue());
        }
        al.sort(new Comparator<Plantilla>() {
            @Override
            public int compare(Plantilla p1, Plantilla p2) {
                return (int) (p1.getSouIncentivat() - p2.getSouIncentivat());
            }
        });
        return al;
    }
    
    public static ArrayList<Plantilla> ordenarPerRol(HashMap<String, Plantilla> p) {
        ArrayList<Plantilla> arr = new ArrayList<>();
        Iterator<Entry<String, Plantilla>> iterador = p.entrySet().iterator();
        while (iterador.hasNext()) {
            Entry<String, Plantilla> entry = iterador.next();
            arr.add(entry.getValue());
        }
        Collections.sort(arr);
        
        return arr;
    }
    
    public void altaPlantilla(){
        Scanner keyboard = new Scanner(System.in);
        altaPersona();

        System.out.print("Escriu numero de la seguretat social: ");
        setSs(keyboard.next());

        System.out.print("Escriu el sou base: ");
        setSouBase(keyboard.nextInt());

        setNumEmpId(++numEmpId);
    }
    
    public void modifica(String dni) {
        String nom;
        String cognom;
        LocalDate datanaix;
        Scanner keyboard = new Scanner(System.in);

        System.out.print("Escriu el nom del nou treballador: ");
        nom = keyboard.nextLine();

        if (!nom.isEmpty()) {
            setNom(nom);
        }

        System.out.print("Escriu el cognom del nou treballador: ");
        cognom = keyboard.nextLine();

        if (!cognom.isEmpty()) {
            setCognom(cognom);
        }

        boolean dataOk;
        do {
            dataOk = true;
            System.out.print("Escriu la data de naixement del treballador de la plantilla: ");
            DateTimeFormatter dateFormat = DateTimeFormatter.ofPattern("yyyy-mm-dd");
            try {
                datanaix = (LocalDate.parse(keyboard.next(), dateFormat));
            } catch (Exception e) {
                dataOk = false;
            }
        } while (!dataOk);
    }
    
    public abstract void calcularSouIncentivat();
    
    @Override
    public void modifica() {
        Scanner kb = new Scanner(System.in);
        super.modifica();

        System.out.print("Escriu el sou base del treballador: ");
        double sou = kb.nextDouble();
        setSouBase(sou);
    }
    
    @Override
    public String toString() {
        return super.toString() + "\nNumero empleat: " + numEmpId+ "\nnuSS: " + ss + "\nSou base: " + souBase + "\nSou incentivat: " + souIncentivat ;
    }  

    @Override
    public int compareTo(Plantilla t) {
        return this.getClass().getSimpleName().compareToIgnoreCase(t.getClass().getSimpleName());
    }

    @Override
    public int compare(Plantilla t, Plantilla t1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}
