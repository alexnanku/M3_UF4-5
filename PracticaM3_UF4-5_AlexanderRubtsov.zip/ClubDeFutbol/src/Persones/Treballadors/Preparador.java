package Persones.Treballadors;

import Comprovacions.Dni;
import Persones.Tecnic.Tecnic;
import java.io.Serializable;
import java.util.Scanner;

public class Preparador extends Tecnic implements Serializable{
    
    private int incentiu;

    public Preparador(int anysExperiencia, String ss, double souBase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(ss, souBase, souIncentivat, dni, nom, cognom, datanaix);
        calcularSouIncentivat();
    }
    
    public Preparador (){
    }
    
    public Preparador altaPreparador() {
        altaTecnic();
        calcularSouIncentivat();
        return this;
    }

    @Override
    public String toString() {
        return super.toString();
    }
    
    public void modifica() {
        super.modifica();
        calcularSouIncentivat();
    }

    @Override
    public void calcularSouIncentivat() {
        setSouIncentivat(getSouBase() + (getAnysExp() * incentiu)); //To change body of generated methods, choose Tools | Templates.
    }
}