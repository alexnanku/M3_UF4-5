package Persones.Treballadors.Jugadors;

import Comprovacions.Dni;
import java.io.Serializable;
import java.util.Scanner;

public class Davanter extends Jugador implements Serializable{

   private int golsFets;
   private int balonsRecuperats;
   private static int incentiuGol = 3000;
   private static int incentiuRecu = 250;

    public Davanter(int golsFets, int balonsRecuperats, boolean titular, String ss, double soubase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(titular, ss, soubase, souIncentivat, dni, nom, cognom, datanaix);
        this.golsFets = golsFets;
        this.balonsRecuperats = balonsRecuperats;
    }
    
    public Davanter(){}
    
    @Override
    public void calcularSouIncentivat() {
        setSouIncentivat(getSouBase() + (golsFets * incentiuGol) + (balonsRecuperats * incentiuRecu)); 
    }

    public Davanter altaDavanter() {
        Scanner kb = new Scanner(System.in);
        altaJugador();
        System.out.print("Escriu els gols anotats: ");
        setGolsFets(kb.nextInt());

        System.out.print("Escriu els balons recuperats: ");
        setBalonsRecuperats(kb.nextInt());
        calcularSouIncentivat(); 
        return this;
    }

    @Override
    public void modifica() {
        Scanner keyboard = new Scanner(System.in);
        super.modifica();

        System.out.print("Gols del jugador: ");
        int gols = keyboard.nextInt();
        setGolsFets(gols);

        System.out.print("Balons recuperats: ");
        int balonsRec = keyboard.nextInt();
        setBalonsRecuperats(balonsRec);
        
        calcularSouIncentivat();
    }
    
    public int getGolsFets() {
        return golsFets;
    }

    public void setGolsFets(int golsFets) {
        this.golsFets = golsFets;
    }

    public int getBalonsRecuperats() {
        return balonsRecuperats;
    }

    public void setBalonsRecuperats(int balonsRecuperats) {
        this.balonsRecuperats = balonsRecuperats;
    }

    @Override
    public String toString() {
        return super.toString() + "\nGols fets: " + golsFets + "\nBalons recuperats: " + balonsRecuperats;
    }
}
