package Persones.Treballadors.Jugadors;

import Comprovacions.Dni;
import Comprovacions.Email;
import Comprovacions.Telefon;
import java.io.Serializable;

public class Migcampista extends Jugador implements Serializable{
    
    private int asistenciesGol;
    private int balonsRecuperats;

    public Migcampista(int asistenciesGol, int balonsRecuperats, boolean titular, String ss, double soubase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(titular, ss, soubase, souIncentivat, dni, nom, cognom, datanaix);
        this.asistenciesGol = asistenciesGol;
        this.balonsRecuperats = balonsRecuperats;
    }

    public int getAsistenciesGol() {
        return asistenciesGol;
    }

    public void setAsistenciesGol(int asistenciesGol) {
        this.asistenciesGol = asistenciesGol;
    }

    public int getBalonsRecuperats() {
        return balonsRecuperats;
    }

    public void setBalonsRecuperats(int balonsRecuperats) {
        this.balonsRecuperats = balonsRecuperats;
    }

    @Override
    public String toString() {
        return super.toString() +  "\n Asistencies de gol: " + asistenciesGol + "\nBalons recuperats: " + balonsRecuperats;
    }
    
    
    
}
