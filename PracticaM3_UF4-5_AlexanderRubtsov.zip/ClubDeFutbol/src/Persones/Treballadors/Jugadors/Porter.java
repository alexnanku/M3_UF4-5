package Persones.Treballadors.Jugadors;

import Comprovacions.Dni;
import Comprovacions.Email;
import Comprovacions.Telefon;
import java.io.Serializable;

public class Porter extends Jugador implements Serializable{
    
    private int parades;
    private int golsRebuts;

    public Porter(int parades, int golsRebuts, boolean titular, String ss, double soubase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(titular, ss, soubase, souIncentivat, dni, nom, cognom, datanaix);
        this.parades = parades;
        this.golsRebuts = golsRebuts;
    }

    public int getParades() {
        return parades;
    }

    public void setParades(int parades) {
        this.parades = parades;
    }

    public int getGolsRebuts() {
        return golsRebuts;
    }

    public void setGolsRebuts(int golsRebuts) {
        this.golsRebuts = golsRebuts;
    }

    @Override
    public String toString() {
        return super.toString() + "Parades: " + parades + "\nGols Rebuts: " + golsRebuts;
    }
}
