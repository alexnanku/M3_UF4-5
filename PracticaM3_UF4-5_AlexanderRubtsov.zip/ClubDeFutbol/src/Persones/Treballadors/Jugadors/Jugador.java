package Persones.Treballadors.Jugadors;

import Comprovacions.Dni;
import Comprovacions.Email;
import Comprovacions.Telefon;
import Persones.Treballadors.Plantilla;
import java.io.Serializable;
import java.util.Scanner;

public class Jugador extends Plantilla implements Serializable{

    private int dorsal;
    private static int dorsalId = 1;
    private boolean titular;

    public Jugador(boolean titular, String ss, double souBase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(ss, souBase, souIncentivat, dni, nom, cognom, datanaix);
        this.dorsal = dorsalId++;
        this.titular = titular;
    }
    
    public Jugador(){}

    public int getDorsal() {
        return dorsal;
    }

    public void setDorsal(int dorsal) {
        this.dorsal = dorsal;
    }

    public boolean isTitular() {
        return titular;
    }

    public void setTitular(boolean titular) {
        this.titular = titular;
    }

    public static int getDorsalId() {
        return dorsalId;
    }

    public static void setDorsalId(int dorsalId) {
        Jugador.dorsalId = dorsalId;
    }
    
    public void altaJugador() {
        Scanner keyboard = new Scanner(System.in);
        altaPlantilla();
        boolean ok = false;

        do {
            System.out.print("El jugador és titular (s/n)? ");
            char titular = Character.toUpperCase(keyboard.nextLine().charAt(0));

            if (titular == 'S') {
                setTitular(true);
                ok = true;
            } else if (titular == 'N') {
                setTitular(false);
                ok = true;
            } else {
                System.out.println("Introdueix un valor vàlid!");
            }
        } while (!ok);
    }
    
    @Override
    public void modifica() {
        Scanner kb = new Scanner(System.in);
        super.modifica();

        boolean ok = false;

        do {
            System.out.print("El jugador és titular (s/n)? ");
            char titular = Character.toUpperCase(kb.nextLine().charAt(0));

            if (titular == 'S') {
                setTitular(true);
                ok = true;
            } else if (titular == 'N') {
                setTitular(false);
                ok = true;
            } else {
                System.out.println("Introdueix un valor vàlid!");
            }
        } while (!ok);

        calcularSouIncentivat();
    }

    @Override
    public String toString() {
        return super.toString() +  "\nDorsal: " + dorsalId + "\nTitular: " + titular;
    }

    @Override
    public void calcularSouIncentivat() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}