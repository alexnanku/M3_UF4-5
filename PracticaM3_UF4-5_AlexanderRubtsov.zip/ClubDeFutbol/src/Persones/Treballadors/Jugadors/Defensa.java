package Persones.Treballadors.Jugadors;

import Comprovacions.Dni;
import Comprovacions.Email;
import Comprovacions.Telefon;
import java.io.Serializable;

public class Defensa extends Jugador implements Serializable{
    
    private int atacsAturats;
    private int balonsRecuperats;

    public Defensa(int atacsAturats, int balonsRecuperats, boolean titular, String ss, double soubase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(titular, ss, soubase, souIncentivat, dni, nom, cognom, datanaix);
        this.atacsAturats = atacsAturats;
        this.balonsRecuperats = balonsRecuperats;
    }

    public int getAtacsAturats() {
        return atacsAturats;
    }

    public void setAtacsAturats(int atacsAturats) {
        this.atacsAturats = atacsAturats;
    }

    public int getBalonsRecuperats() {
        return balonsRecuperats;
    }

    public void setBalonsRecuperats(int balonsRecuperats) {
        this.balonsRecuperats = balonsRecuperats;
    }

    @Override
    public String toString() {
        return super.toString() + "\n Atacs aturats: " + atacsAturats + "\nBalons recuperats: " + balonsRecuperats;
    }    
}