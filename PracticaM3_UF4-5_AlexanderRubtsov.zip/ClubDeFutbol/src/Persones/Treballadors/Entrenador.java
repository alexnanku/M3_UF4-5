package Persones.Treballadors;

import Comprovacions.Dni;
import Persones.Tecnic.Tecnic;
import java.io.Serializable;
import java.util.Scanner;

public class Entrenador extends Tecnic implements Serializable{

    private int numTrofeus;
    private int primaTrofeu = 5000;

    public Entrenador(String ss, double souBase, double souIncentivat, Dni dni, String nom, String cognom, String datanaix) {
        super(ss, souBase, souIncentivat, dni, nom, cognom, datanaix);
        this.numTrofeus = numTrofeus;
        calcularSouIncentivat();
    }

    public Entrenador() {
    }

    public int getNumTrofeus() {
        return numTrofeus;
    }

    public void setNumTrofeus(int numTrofeus) {
        this.numTrofeus = numTrofeus;
    }
    
    public Entrenador altaEntrenador() {
        Scanner keyboard = new Scanner(System.in);
        altaTecnic();
        System.out.print("Escriu el número de trofeus guanyats: ");
        setNumTrofeus(keyboard.nextInt());
        calcularSouIncentivat();
        return this;
    }
    
    public void modifica() {
        Scanner keyboard = new Scanner(System.in);
        super.modifica();
        System.out.print("Escriu el número nou de trofeus guanyats: ");
        int numTrofeus = keyboard.nextInt();
        setNumTrofeus(numTrofeus);
        calcularSouIncentivat();
    }

    @Override
    public void calcularSouIncentivat() {
        setSouIncentivat(getSouBase() + (getNumTrofeus() * primaTrofeu));
    }
    
    
}
