package Comprovacions;

import java.util.regex.Pattern;

public class Email {
    
    private String ema;
    
    public boolean validarEmail(String email) {
        Pattern pattern = Pattern.compile("^[_A-Za-z0-9-\\+]+(\\.[_A-Za-z0-9-]+)*@[A-Za-z0-9-]+(\\.[A-Za-z0-9]+)*(\\.[A-Za-z]{2,})$");
        java.util.regex.Matcher mather = pattern.matcher(email);
 
        if (mather.find() == true) {
            return true;
        } else {
            return false;
        }
    }
        
    public Email(String email) {
        this.ema = email;
    }

    public Email(){}

    @Override
    public String toString() {
        return ema;
    }

    public String getEma() {
        return ema;
    }

    public void setEma(String email) {
        this.ema = email;
    }
    
}
