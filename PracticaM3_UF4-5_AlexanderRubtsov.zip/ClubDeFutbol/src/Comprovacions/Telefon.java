package Comprovacions;

import java.util.regex.Pattern;

public class Telefon {
    
    private String tele;
    
    public boolean validarTelefon(String movil) {
        Pattern pattern = Pattern.compile("^(/+34|0034|34)?[6789]/d{8}$");
        return pattern.matcher(movil).matches();
    }

    public Telefon(String telefon) {
        this.tele = telefon;
    }
    
    public Telefon(){}

    public String getTele() {
        return tele;
    }

    public void setTele(String telefon) {
        this.tele = tele;
    }
}

